#!/bin/bash

set -euo pipefail

usage() { echo \
"Usage: $0
  [-t <bazel_target>] (Mandatory, if -s flag is not set)
  [-o <klocwork_output_path>] (Optional, defaults to cwd)
  [-p <klocwork_project>] (Optional, defaults to test_project)
  [-s Flag: Skip creation of buildspec]
  [-a Flag: Skip analysis with Klocwork, only create the buildspec]" \
1>&2; }

SKIP_BUILD_SPEC_CREATION=0
ANALYSE=1
SERVER_URL=http://localhost:8080
# location of Klocwork tools. Typically /opt/klocwork/server20.3/bin or /opt/klocwork/kwbuildtools20.3/bin
KLOCWORK_BIN=/home/vagrant/klocwork/server20.3/bin

while getopts "t:o:p:as" option
    do
    case "${option}"
    in
    t) BAZEL_TARGET=${OPTARG};;
    o) KLOCWORK_OUTPUT_PATH=${OPTARG};;
    p) KLOCWORK_PROJECT=${OPTARG};;
    s) SKIP_BUILD_SPEC_CREATION=1;;
    a) ANALYSE=0;;
    h | *) usage; exit 1;
    esac
done
if [ ! -d "${KLOCWORK_BIN}" ]; then
  echo "ERROR: Klocwork BuildTools not installed at ${KLOCWORK_BIN}"
  exit 1
fi

readonly SCRIPT_DIR="$(dirname "$0")"
KLOCWORK_OUTPUT_PATH=${KLOCWORK_OUTPUT_PATH:-$(pwd)}
mkdir -p "${KLOCWORK_OUTPUT_PATH}"
echo "INFO: Using '${KLOCWORK_OUTPUT_PATH}' as Klocwork output directory..."

KLOCWORK_PROJECT=${KLOCWORK_PROJECT:-test_project}
echo "INFO: Using '${KLOCWORK_PROJECT}' as Klocwork project..."

if [ "${SKIP_BUILD_SPEC_CREATION}" -eq "0" ]; then
# CUSTOMIZE this "if" block as per your bazel build process

  if [ -z "${BAZEL_TARGET+x}" ]; then
    echo "ERROR: No target specified. Use -t option to specify a target."
    usage
    exit 1
  fi

  echo "INFO: Creating Klocwork build specification..."
  readonly EXEC_ROOT=$(bazel info execution_root)
  if [ -z "$EXEC_ROOT" ]; then
    echo "ERROR: Bazel workspace can not be found, run this script from a valid bazel workspace."
    exit 1
  fi

  echo "INFO: Building and creating KW spec for '${BAZEL_TARGET}' ..."
  BAZEL_CONFIG=""
  pushd "$(bazel info workspace)"
  BAZEL_ARGS="--show_result 1 --noshow_progress --color=no --output_filter=DONT_MATCH_ANYTHING"
  bazel build ${BAZEL_TARGET} ${BAZEL_CONFIG} ${BAZEL_ARGS}
  popd
echo python "${SCRIPT_DIR}/ekw_bazel.py" -k "${KLOCWORK_BIN}" -o "${KLOCWORK_OUTPUT_PATH}/kwinject.out" -w ${BAZEL_TARGET}
  python "${SCRIPT_DIR}/ekw_bazel.py" -k "${KLOCWORK_BIN}" -o "${KLOCWORK_OUTPUT_PATH}/kwinject.out" -w "$(pwd)" ${BAZEL_TARGET}
# ----- End of ekw_bazel support steps -----

fi

if [ "${ANALYSE}" -eq "1" ]; then
  echo "INFO: Running integration Klocwork analysis..."
  pushd "${KLOCWORK_OUTPUT_PATH}" > /dev/null 2>&1

  if [ -f "kwinject.out" ]; then
    "${KLOCWORK_BIN}/kwbuildproject" --url "${SERVER_URL}/${KLOCWORK_PROJECT}" -o kwtables kwinject.out --force || true
	"${KLOCWORK_BIN}/kwadmin" --url ${SERVER_URL} load "${KLOCWORK_PROJECT}"  kwtables
	echo "INFO: Analysis results are available in project ${KLOCWORK_PROJECT} on the Klocwork portal"
  else
    echo "ERROR: Build specification could not be found, aborting..."
    exit 1
  fi
  popd > /dev/null 2>&1
fi
