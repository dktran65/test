# **************************************************************************************************
#  Developed By: Emenda Ltd. (www.emenda.com)
#  Description: Create Klocwork build specification from Bazel project
#
#  $LastChangedDate: 2019-03-29
#  $Version: 1.0
#    - Intial release
#            2.0 (J Chapman)
#    - renamed as script now creates build spec.
#
# Disclaimer: Please note that this software or software component is released by Emenda Software Ltd
# on a non-proprietary basis for commercial or non-commercial use with no warranty. Emenda Software Ltd
# will not be liable for any damage or loss caused by the use of this software. Redistribution is only
# allowed with prior consent.
#
# **************************************************************************************************

import os
import sys
import re
import argparse
import subprocess

CppCompileKey = "CppCompile"
CppLinkKey = "CppLink"

parser = argparse.ArgumentParser(prog="ekw_bazel.py",
                                 description="Convert Bazel exec log to Klocwork build spec file")
parser.add_argument("target", help="Bazel build target (i.e. //main:hello-world)")
parser.add_argument('-o', "--output", default="kwinject.out", help="Output Klocwork build spec file")
parser.add_argument('-w', "--working_dir", default=os.getcwd(), help="Base working directory for project")
parser.add_argument('-k', "--klocwork_bin", default=".", help="Klocwork install bin directory (no trailing /)")


class c_action:
    def __init__(self):
        self.mnemonic = None
        self.args = []
        self.tool = None
        self.includeFlag = None
        self.skip = ["-B", "-U", "-MD", "-frandom-seed"]
        self.skip_with_arg = ["-MF"]
        self.skip_next_arg_flag = None

    def startsWithSkipped(self, val):
        for skip in self.skip:
            if val.startswith(skip):
                return True
        return False

    def _checkArg(self, val):
        if self.startsWithSkipped(val):
            return None
        elif self.skip_next_arg_flag:
            self.skip_next_arg_flag = None
            return None
        elif val in self.skip_with_arg:
            self.skip_next_arg_flag = True
            return val
        elif val.startswith('-D'):
            val = val.replace("\\\"", "")
            self.args.append("-D")
            return val[2:]
        elif val.startswith('-i'):
            # print_action outputs multiple variants of external paths
            # Attempt to make path unique for later handling
            self.includeFlag = val
        elif self.includeFlag:
            m = re.search(r'[\/](external\/].*)$', val)
            if m:
                val = m.group(1)
                if val in self.args:
                    self.args.pop()  # Remove last '-i'
                    return None
            self.includeFlag = None
        elif val.startswith('@'):
            if os.path.exists(val[1:]):
                print("WARNING: Arguments file not parsed: %s" % val[1:])
            return None

        return val

    def addArg(self, val):
        val = val.replace("arguments: ", '').replace("\\\"", '').strip('"').strip()
        val = self._checkArg(val)
        if val:
            if not val.startswith('-') and ('/' in val or '\\' in val):  # I know this is a nasty way of identifing path
                newPath = check_path(val)
                if newPath:
                    val = newPath
            self.args.append(val)
            if not self.tool:
                self.tool = val

    def __str__(self):
        return str({'mnemonic': self.mnemonic, 'args': self.args})

    def __repr__(self):
        return self.__str__()


def check_path(path):
    global bazel_path
    global path_dict
    global path_missing_list
    global project_name
    bazel_project_name = "bazel-%s" % project_name

    if os.name != 'posix':
        return path

    if path.startswith("bazel-"):
        # Exclude any 'bazel-' paths as these should be OK
        return path
    elif path in path_dict:
        return path_dict[path]
    elif path in path_missing_list:
        return None
    elif os.path.isabs(path):
        # Absolute path
        path_dict[path] = path
        return path
    elif os.path.isfile(path):
        path_dict[path] = path
        return path
    elif path.startswith(bazel_project_name):
        new_path = os.path.join(bazel_path, path[len(bazel_project_name) + 1:])
        if not os.path.exists(new_path):
            print("WARNING: Project path cannot be mapped: %s" % path)
            path_missing_list.append(path)
            return None
        else:
            path_dict[path] = new_path
            return new_path
    else:
        new_path = os.path.join(bazel_project_name, path)
        if os.path.exists(new_path):
            path_dict[path] = new_path
            return new_path

        if path.startswith("external"):
            new_path = os.path.join(bazel_path, path)
        else:
            new_path = os.path.join(bazel_path, "external", project_name, path)
        if os.path.exists(new_path):
            path_dict[path] = new_path
            return new_path

        print("WARNING: Path cannot be mapped: %s" % path)
        path_missing_list.append(path)
        return path


def output_dict(d):
    d = str(d)
    d = d.replace('"', '\'').replace("'", '"').replace(": ", ":").replace('u"', '"')
    return d


def get_bazel_path(bazel_out):
    path_split = os.path.split(bazel_out)
    if len(path_split) < 2:
        print("ERROR: Processing error getting execroot!")
        sys.exit(1)
    if path_split[1] == "execroot":
        return path_split[0]
    else:
        return get_bazel_path(path_split[0])


def setBazelVariables(working_dir):
    global project_name
    global bazel_project_dir
    global bazel_path

    project_name = os.path.split(working_dir)[1].replace('-', '_')
    bazel_project_dir = os.path.join(working_dir)
    if not os.path.exists(bazel_project_dir):
        print("ERROR: Expected project specific bazel directory for " +
              "include path mapping: %s" % bazel_project_dir)
        sys.exit(1)

    bazel_out = os.path.join(working_dir, "bazel-out")
    if not os.path.exists(bazel_out):
        print("ERROR: Working directory does not appear to be valid, " +
              "would expect to find 'bazel-out':\n\t%s" % bazel_out)
        sys.exit(1)

    if os.name == 'posix':
        if not os.path.islink(bazel_out):
            print("ERROR: Working directory does not appear to be valid, " +
                  "would expect to find symlink 'bazel-out':\n\t%s" % bazel_out)
            sys.exit(1)
        bazel_out = os.path.realpath(bazel_out)
        execroot = "%sexecroot%s" % (os.path.sep, os.path.sep)
        if execroot not in bazel_out:
            print("ERROR: No execroot in bazel_out symlink: %s" % bazel_out)
            sys.exit(1)
        bazel_path = get_bazel_path(bazel_out)
    else:
        bazel_path = working_dir


def getLineValue(line):
    val = re.sub(r'[^:]+:\s+"(.*)"\s*$', r'\1', line)
    return val


def main():
    global bazel_path  # Get unique bazel path
    global path_dict  # Store matches to improve performance
    path_dict = {}
    global path_missing_list  # Store missing paths to improve performance
    path_missing_list = []
    global project_name

    args = parser.parse_args()
    print(args)
    bs_file = args.output
    trace_file = os.path.splitext(bs_file)[0] + '.trace'
    working_dir = args.working_dir
    klocwork_bin = args.klocwork_bin

    # Need to run build before setting Bazel paths
    setBazelVariables(working_dir)

    # Run Bazel aquery to get build calls
    logFileName = "bazel_aquery.log"
    cmd = "bazel aquery \'mnemonic(\"Cpp.*\", deps(%s))\' --output=textproto > %s" % (args.target, logFileName)
    subprocess.check_output(cmd, shell=True)

    # Start creating Klocwork trace file
    fp = open(trace_file, 'w')
    fp.write(output_dict({"version": 101}) + '\n')
    fp.write(output_dict({"creator": "ekw_bazel.py, Emenda Bazel Exec Log Conversion"}) + '\n')
    fp.write(output_dict({"env": os.environ}) + '\n')
    currentAction = c_action()

    # Loop through Bazel output and update trace
    fp2 = open(logFileName, 'r')
    for line in fp2:
        line = line.strip()
        if not line:
            continue
        if line == '}' and currentAction.mnemonic:
            # Add existing action to list
            if currentAction.mnemonic == CppCompileKey or currentAction.mnemonic == CppLinkKey:
                trace = {}
                trace['id'] = 0
                trace['work_dir'] = working_dir
                trace['executable'] = currentAction.tool
                trace['args'] = currentAction.args
                fp.write(output_dict(trace) + '\n')
            else:
                continue
            currentAction = c_action()
        elif line.startswith("mnemonic:"):
            currentAction.mnemonic = getLineValue(line)
        elif line.startswith("arguments:"):
            currentAction.addArg(line)

    fp.close()
    fp2.close()

    cmd = "%s/kwinject -w -t %s -o %s" % (klocwork_bin, trace_file, bs_file)
    subprocess.check_output(cmd, shell=True)


# ======= For main function use ======
if __name__ == '__main__':
    main()
